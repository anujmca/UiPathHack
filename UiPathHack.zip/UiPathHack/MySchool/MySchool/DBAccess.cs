﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Data;
using MySql.Data;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace MySchool
{
    public class DBAccess
    {
        public static void GetData()
        {
            var dbCon = DBConnection.Instance();
            dbCon.DatabaseName = "GreenApple";
            if (dbCon.IsConnect())
            {
                string query = "select	* from GreenApple.StudentDetails";
                var cmd = new MySqlCommand(query, dbCon.Connection);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string someStringFromColumnZero = reader.GetString(0);
                    string someStringFromColumnOne = reader.GetString(1);
                    Console.WriteLine(someStringFromColumnZero + "," + someStringFromColumnOne);
                }
                dbCon.Close();
            }
        }

        public static bool AddStudent(string studentName, string fatherName, string motherName, DateTime studenDob, string Ids, string phone, string status)
        {
            var impactedRowsCount = 0;
            var dbCon = DBConnection.Instance();
            dbCon.DatabaseName = "GreenApple";
            if (dbCon.IsConnect())
            {
                string query = $"Insert into StudentDetailsApplied(StudentName, FatherName, MotherName, StudentDOB, Ids, Phone, Status) " +
                               $"values('{studentName}', '{fatherName}', '{motherName}', '{studenDob.ToString("dd-MMM-yyyy")}', '{Ids}', '{phone}', '{status}')";
                var cmd = new MySqlCommand(query, dbCon.Connection);
                impactedRowsCount = cmd.ExecuteNonQuery();                
                //dbCon.Close();
            }

            return impactedRowsCount != 0;
        }
    }
}

namespace Data
{
    public class DBConnection
    {
        private DBConnection()
        {
        }

        private string databaseName = "GreenApple";
        public string DatabaseName
        {
            get { return databaseName; }
            set { databaseName = value; }
        }

        public string Password { get; set; }
        private MySqlConnection connection = null;
        public MySqlConnection Connection
        {
            get { return connection; }
        }

        private static DBConnection _instance = null;
        public static DBConnection Instance()
        {
            if (_instance == null)
                _instance = new DBConnection();
            return _instance;
        }

        public bool IsConnect()
        {
            if (Connection == null)
            {
                if (String.IsNullOrEmpty(databaseName))
                    return false;
                string connstring = string.Format("Server=uipathhack.czklhdtrjtzv.ap-south-1.rds.amazonaws.com; database={0}; UID=GreenApple; password=GreenApple", databaseName);
                connection = new MySqlConnection(connstring);
                connection.Open();
            }

            return true;
        }

        public void Close()
        {
            connection.Close();
        }
    }
}