﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MySchool
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        public void Submit_Click(object sender, EventArgs e)
        {
            var dob = DateTime.Parse(StudentDOB.Value);
            bool isAdded = DBAccess.AddStudent(StudentName.Value, FatherName.Value, MotherName.Value, dob, Ids.Value, Phone.Value, "Pending");

            if (isAdded)
            {
                divForm.Visible = false;
                divMessage.Visible = true;
            }
        }

        public void Reset_Click(object sender, EventArgs e)
        {
            StudentName.Value = FatherName.Value = MotherName.Value = StudentDOB.Value = Ids.Value = Phone.Value = string.Empty;
            divForm.Visible = true;
            divMessage.Visible = false;
        }
    }
}